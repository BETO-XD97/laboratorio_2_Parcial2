﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Entidades
{
    public static class AccesoDatos
    {
        private static SqlCommand comando;
        private static SqlConnection conexion;

        static AccesoDatos() 
        {
            conexion = new SqlConnection("Server=.;Database=20240701-SP;Trusted_Connection=True;");
            comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandType = System.Data.CommandType.Text;
        }

        public static void ActualizarSerie(Serie serie)
        {
            try
            {
                comando.Parameters.Clear();
                conexion.Open();
                comando.CommandText = "UPDATE dbo.series SET nombre = @nombre, genero = @genero WHERE alumno = @alumno";
                comando.Parameters.AddWithValue("@nombre", serie.Nombre);
                comando.Parameters.AddWithValue("@genero", serie.Genero);
                comando.Parameters.AddWithValue("@alumno", "Roberto rocabado");
                comando.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Logger.Log(ex.Message);
                throw new Exception("Error de conectarse a la base de datos");
            }
            finally
            {
                conexion.Close();
            }
        }

        public static List<Serie> ObtenerBackLog()
        {
            List<Serie> series = new List<Serie>();

            try
            {
                comando.Parameters.Clear();
                conexion.Open();
                comando.CommandText = "SELECT * FROM dbo.series";
                SqlDataReader dataReader = comando.ExecuteReader();

                while (dataReader.Read())
                {
                    series.Add(new Serie(dataReader["nombre"].ToString(), dataReader["genero"].ToString())); 
                
                }

                return series;
            }
            catch (Exception ex)
            {
                Logger.Log(ex.Message);
                throw new Exception("Error de conectarse a la base de datos");
            }
            finally
            {
                conexion.Close();
            }
        }
    }
}
