﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Serie
    {
        private string genero;
        private string nombre;
        private string alumno;

        public Serie()
        {

        }

        public Serie(string genero, string nombre) : this()
        {
            this.genero = genero;
            this.nombre = nombre;
        }

        public Serie(string genero, string nombre, string alumno) : this(genero, nombre)
        {
            this.alumno = alumno;
        }

        public string Genero { get => genero; set => genero = value; }
        public string Nombre { get => nombre; set => nombre = value; }

        public override string ToString()
        {
            return $"Nombre: {this.Nombre} / Genero: {this.Genero}";
        }
    }
}
