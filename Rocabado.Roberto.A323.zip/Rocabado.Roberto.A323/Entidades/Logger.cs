﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public static class Logger
    {
        public static void Log(string mensaje)
        {

            string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "excepcion.txt");
            string logMessage = $"{DateTime.Now}: {mensaje}";

            using (StreamWriter writer = new StreamWriter(path, true))
            {
                writer.WriteLine(logMessage);
            }
        }
    }
}
