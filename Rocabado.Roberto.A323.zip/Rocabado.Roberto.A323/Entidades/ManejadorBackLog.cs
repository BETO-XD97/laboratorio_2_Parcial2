﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public delegate void DelegadoBackLog(Serie ciudadano);

    public class ManejadorBackLog
    {
        public event DelegadoBackLog serieParaVer;

        public void IniciarManejador(List<Serie> series)
        {
            Task mover = Task.Run(() => MoverSeries(series));
        }

        private void MoverSeries(List<Serie> series)
        {
            
            for(int i = 0; i < series.Count; i++)
            {

                int indiceRandom = series.GenerarRandom();

                Serie serie = series[indiceRandom];

                AccesoDatos.ActualizarSerie(serie);

                Thread.Sleep(1500);

                serieParaVer?.Invoke(serie);
            }
        }
    }
}
