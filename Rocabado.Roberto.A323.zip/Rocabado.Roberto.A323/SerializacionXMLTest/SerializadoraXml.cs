using System.Xml.Serialization;
using Entidades;

namespace UnitTests
{
    [TestClass]
    public class SerializadoraJson
    {
        [TestMethod]
        public void SerializadoraGuardarXML_DeberiaSerializarFormatoXML()
        {
            // Arrange
            List<Serie> backLog = new List<Serie>
            {
            new Serie { Nombre = "galactus", Genero = "supeheroe"},
            new Serie { Nombre = "la bala perdida", Genero = "accion"}
            };

            Serializadora serializadora = new Serializadora();
            string rutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string rutaXml = Path.Combine(rutaEscritorio, "BacklogPrueba.xml");

            //Act
            serializadora.Guardar(backLog, rutaXml);

            // Assert
            Assert.IsTrue(File.Exists(rutaXml), "El archivo XML no fue creado.");

            List<Serie> deserializedBackLog;
            XmlSerializer serializer = new XmlSerializer(typeof(List<Serie>));
            using (StreamReader reader = new StreamReader(rutaXml))
            {
                deserializedBackLog = (List<Serie>)serializer.Deserialize(reader);
            }

            Assert.AreEqual(backLog.Count, deserializedBackLog.Count);

            for (int i = 0; i < backLog.Count; i++)
            {
                Assert.AreEqual(backLog[i].Nombre, deserializedBackLog[i].Nombre);
                Assert.AreEqual(backLog[i].Genero, deserializedBackLog[i].Genero);
            }
        }
    }
}


