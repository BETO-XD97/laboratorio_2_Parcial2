using System.Text.Json;
using System.Xml.Serialization;
using Entidades;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class SerializadoraJso
    {
        [TestMethod]
        public void SerializadoraGuardarJson_DeberiaSerializarFormatoJson()
        {
            // Arrange
            List<Serie> backLog = new List<Serie>
            {
                new Serie { Nombre = "Galactus", Genero = "Superheroe" },
                new Serie { Nombre = "La Bala Perdida", Genero = "Accion" }
            };

            Serializadora serializadora = new Serializadora();
            string rutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string rutaJson = Path.Combine(rutaEscritorio, "BacklogJson.json");

            // Act
            ((IGuardar<List<Serie>>)serializadora).Guardar(backLog, rutaJson);

            // Assert
            Assert.IsTrue(File.Exists(rutaJson), "El archivo JSON no fue creado.");

            List<Serie> deserializedBackLog;
            using (StreamReader reader = new StreamReader(rutaJson))
            {
                string json = reader.ReadToEnd();
                deserializedBackLog = JsonSerializer.Deserialize<List<Serie>>(json);
            }

            Assert.AreEqual(backLog.Count, deserializedBackLog.Count);

            for (int i = 0; i < backLog.Count; i++)
            {
                Assert.AreEqual(backLog[i].Nombre, deserializedBackLog[i].Nombre);
                Assert.AreEqual(backLog[i].Genero, deserializedBackLog[i].Genero);
            }


        }
    }
}


